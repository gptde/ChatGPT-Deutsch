<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly.
?>

<?php include WPAICG_PLUGIN_DIR.'lib/views/chat/pdfs.php'; ?>